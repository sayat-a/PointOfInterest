from django.apps import AppConfig


class PoiApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'poi.poi_api'
